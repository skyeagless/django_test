from django.shortcuts import render
from django.shortcuts import HttpResponse #网页返回内容所需
from django.urls import reverse
from django.http import HttpResponseRedirect
# Create your views here.
def add(request,a,b):
    c=int(a)+int(b)
    return HttpResponse(str(c))

def old_add_redirect(request,a,b):
    return HttpResponseRedirect(reverse('add',args=(a,b)))

def index(request):
    return render(request,"home.html")