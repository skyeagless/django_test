
import xadmin
from xadmin import views
from .models import EmailVerifyRecode,Banner

class BaseSetting(object):
    enable_themes = True
    use_bootswatch = True

class GlobalSettings(object):
    site_title = "后台管理系统"
    site_footer= "Designed By SkyEagle"
    menu_style = "accordion"


class EmailVerifyRecordAdmin(object):
    list_display=["code","email","send_type","send_time"]
    search_fields=["code","email","send_type"]
    list_filter=["code","email","send_type","send_time"]

class BannerAdmin(object):
    list_display = ["title", "image_banner", "url", "index","add_time"]
    search_fields = ["title", "image_banner", "url", "index"]
    list_filter = ["title", "image_banner", "url", "index","add_time"]


xadmin.site.register(EmailVerifyRecode,EmailVerifyRecordAdmin)
xadmin.site.register(Banner,BannerAdmin)
xadmin.site.register(views.BaseAdminView,BaseSetting)
xadmin.site.register(views.CommAdminView,GlobalSettings)