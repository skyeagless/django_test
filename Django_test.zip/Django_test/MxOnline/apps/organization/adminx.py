import xadmin
from .models import CityDict, CourseOrg, Teacher

class CityDictAdmin(object):
    list_display = ['name', 'desc','add_time']  # 列表显示
    search_fields = ['name', 'desc']  # 搜索
    list_filter = ['name', 'desc','add_time']    # 筛选

class CourseOrgAdmin(object):
    list_display = ['city', 'name','desc','click_nums','fav_nums','image','address','add_time']  # 列表显示
    search_fields = ['city', 'name','desc','click_nums','fav_nums','image','address']   # 搜索
    list_filter = ['city__name', 'name','desc','click_nums','fav_nums','image','address','add_time']     # 筛选

class TeacherAdmin(object):
    list_display = ['org', 'name','work_years','work_company','work_position','points','click_nums','fav_nums','add_time']  # 列表显示
    search_fields = ['org', 'name','work_years','work_company','work_position','points','click_nums','fav_nums']  # 搜索
    list_filter = ['org__name', 'name','work_years','work_company','work_position','points','click_nums','fav_nums','add_time']    # 筛选

xadmin.site.register(CityDict, CityDictAdmin)
xadmin.site.register(CourseOrg, CourseOrgAdmin)
xadmin.site.register(Teacher, TeacherAdmin)