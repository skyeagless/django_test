#_*_ coding:utf-8 _*_
from django.db import models

# Create your models here.
class UserMessage(models.Model):
    object_id = models.CharField(max_length=50,primary_key=True,verbose_name=u"主键",default='')
    name = models.CharField(max_length=20,null=True,blank=True,default="",verbose_name=u"用户名")
    email=models.EmailField(verbose_name=u"邮箱")
    address=models.CharField(max_length=100,verbose_name=u"联系地址")
    message=models.CharField(max_length=500,verbose_name=u"留言信息")

    class Meta:#verbose_name的意思很简单，就是给你的模型类起一个更可读的名字一般定义为中文
        verbose_name=u"用户留言信息"
        verbose_name_plural=verbose_name
        #Django 模型类的Meta是一个内部类，它用于定义一些Django模型类的行为特性。下面对此作一总结

