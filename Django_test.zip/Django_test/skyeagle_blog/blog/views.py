from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from . import models

# Create your views here.
def index(request):  #主页，传到前端一个article列表
    articles=models.Article.objects.all()#获得所有文章,返回一个内置列表
    return render(request, 'blog/index.html',{'articles':articles})

def article_page(request,article_id): #文章显示页，通过文章数据库的主键来识别
    article=models.Article.objects.get(pk=article_id) #响应函数对应文章表的主键
    return render(request,'blog/article_page.html',{'article':article})

def edit_page(request,article_id): #编辑界面（id=0，则进入新建界面，否则通过文章数据库的ID来进入修改界面，但实际是一个界面）
    if str(article_id)=='0':
        return render(request,'blog/article_edit.html')
    else:#否则进入修改界面，从数据库中拿数据对象
        article = models.Article.objects.get(pk=article_id)
        return render(request, 'blog/article_edit.html',{"article":article})

def edit_action(request): #提交表（summit）的动作，新建或修改
    title = request.POST.get('title','TITLE')
    content =request.POST.get("content",'CONTENT')
    article_id =request.POST.get("article_id","0")
    if article_id == '0':
        models.Article.objects.create(title=title,content=content)
        #articles = models.Article.objects.all()  # 获得所有文章,返回一个内置列表
        #return render(request, 'blog/index.html', {'articles': articles})
        return HttpResponseRedirect('/blog/index')
    else:
        article = models.Article.objects.get(pk=article_id)
        article.title = title
        article.content = content
        article.save()
        return HttpResponseRedirect('/blog/index')





